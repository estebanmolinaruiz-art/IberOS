# IberOS+ · Restauración visual del flyer

## Contenido
- `index.html`: portada basada en la imagen exacta aprobada, con zonas interactivas accesibles y búsqueda.
- `flyer-portada.jpg`: imagen oficial aportada en el proyecto.

## Instalación propuesta
Los dos archivos se colocan juntos en la raíz de la carpeta publicada de GitHub Pages (`site/` si esa es la fuente del despliegue). **Antes de sustituir `site/index.html`, conservar el original y comprobar la fuente real de GitHub Pages.** El resto de rutas (`corpus/`, `atlas/`, `laboratorio/`...) deben mantenerse.

## Límites importantes
- La portada de escritorio utiliza una imagen fija completa. No es una reconstrucción editable ni accesible de cada elemento.
- En móvil se muestra una versión HTML alternativa, no la misma composición fotográfica.
- Los números impresos dentro del flyer son ilustrativos y no se presentan como métricas verificadas.
- El enlace «Acceso / Registro» dirige a Comunidad porque aún no hay autenticación demostrada.
- Los enlaces a rutas internas requieren desplegar en la raíz de IberOS para funcionar; al abrirlo localmente solo se puede explorar el aspecto.
- La web funcional existente **no debe reemplazarse** hasta efectuar pruebas y aprobación visual.
