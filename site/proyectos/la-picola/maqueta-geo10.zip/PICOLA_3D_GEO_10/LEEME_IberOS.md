# IberOS · PICOLA-3D — GEO-10

Maqueta documental parcial, 22 de octubre de 2026. Fase ibérica.

Se ha aplicado a una nueva maqueta editable la transformación provisional GEO-09 entre la figura 3 de Moret–Badie y YARQ_2. No es una actualización del archivo REC-63, que no se recuperó en esta tanda. La búsqueda de ese identificador y de Picola no devolvió un archivo recuperable; eso no demuestra que el original no exista.

## Qué contiene

- **IberOS_Picola_3D.html:** visor autónomo, sin conexión ni bibliotecas externas. Permite girar, ver en planta, ocultar capas y variar la altura de representación.
- **IberOS_Picola.obj + IberOS_Picola.mtl:** geometría editable en metros, con materiales separados; importar conjuntamente. Ejes X Este, Y Norte de cuadrícula, Z arriba.
- **modelo_parametrico.json:** 63 huellas manuales simplificadas, con coordenadas de lectura originales, evidencia, alturas visuales y origen local.
- **huellas_EPSG25830.geojson:** intercambio GIS en coordenadas proyectadas EPSG:25830. Usa el convenio antiguo con miembro CRS explícito; no es GeoJSON RFC 7946 en longitud/latitud. Al importar, asignar EPSG:25830.
- **IberOS_PICOLA_GEO10_maqueta.png:** vista de conjunto firmada.
- **construir.py + visor_base.html:** reproducción desde la raíz que contiene GEO-09. Se adjuntan los dos JSON necesarios para reproducirla.

## Parámetros conservados

La matriz y el desplazamiento de GEO-09 se aplican sin imponer ángulos rectos, sin reescalar cada muro y sin un giro adicional para redondear azimuts. El modelo usa coordenadas de cuadrícula; la convergencia de meridianos se conserva como metadato para expresar los azimuts geográficos aproximados.

| Lado | Cuadrícula | Geográfico aproximado |
|---|---:|---:|
| Cortina NO | 56,956° | 58,463° |
| Cortina NE | 135,922° | 137,428° |

Los decimales documentan el cálculo heredado, no exactitud arqueológica. Orientaciones de trabajo comunicadas: aproximadamente 58° y 137°. Los azimuts pertenecen a las caras seleccionadas en GEO-05/GEO-09; el trazado simplificado de cada huella puede diferir ligeramente y no sustituye esa medición. NO/NE son nombres de lados del recinto, no rumbos de marcha.

## Evidencia y volumen

41 huellas representan trazos oscuros conservados en la figura histórica; 22 representan trazos claros restituidos por los autores. Se han elegido polígonos simples manualmente: no reproducen todas las piedras, todos los fragmentos ni los espesores medidos en excavación. Los identificadores son del modelo, no nuevas unidades estratigráficas.

**Toda altura de esta entrega es una decisión visual.** La capa documentada se representa a 0,80 m y la restituida a 0,12 m, para distinguirlas. No son alturas conservadas, cotas antiguas ni propuestas de alzado. El deslizador permite experimentar con la representación; no cambia su estatus. La base Z=0 es arbitraria, no una altitud ETRS89.

Se conserva la discontinuidad de la puerta NE; no se propone dintel, anchura de paso medida, hojas ni torre adicional. Tampoco se han añadido cubiertas, almenas o profundidad del foso. Una zona vacía en esta maqueta significa que no se ha modelado, no que se haya demostrado una plaza o terreno vacío antiguo.

## Límites del ajuste

GEO-09 usa cuatro referencias gráficas y dos comprobaciones reservadas del ajuste final; todas habían sido vistas durante la exploración. Las comprobaciones comparten contextos con los controles y no son ciegas ni independientes. Sus residuos de 0,17 y 0,50 m comparan planos y no acreditan precisión sobre el terreno. No hay controles topográficos externos aceptados. La posición absoluta sigue siendo provisional.

La retícula GEO-02 mantiene en su JSON histórico el contador de homologías anterior al ajuste GEO-09: ese valor se conserva como procedencia, no como estado vigente. La autoridad del ajuste de esta maqueta es registro_encuentros.json de GEO-09.

## Coordinación con PICOLA-CAMINOS y paisaje

La maqueta exporta el mismo origen y transformación documental para poder superponer capas, con incertidumbre explícita. La puerta publicada es una referencia para contrastar accesos; no demuestra que un camino moderno, romano o CAM-A02 llegue a ella en la fase ibérica. No se ha escrito ni modificado otro hilo o repositorio.

No se traza todavía una paleocosta o humedal concreto en este archivo. Antes de añadirlos como geometría se deben recuperar las capas y fuentes del proyecto de paisaje, comprobar sus fechas y separar escenarios. Suelo plano del visor = soporte gráfico, no reconstrucción topográfica antigua. La reconstrucción completa sigue pendiente de completar huellas, cotas, secciones, alzados y paisaje con evidencia trazable.

## Fuente y atribución

Moret, P. y Badie, A. (1998), «Metrología y arquitectura modular en el puerto de La Picola (Santa Pola, Alicante) al final del siglo V a.C.», Archivo Español de Arqueología 71, 53–61, figura 3, p. 55. DOI: https://doi.org/10.3989/aespa.1998.v71.274

Las capas siguen la distinción oscuro/claro de esa figura. Es una derivación esquemática de estudio no comercial. La copia de fuente conservada en GEO-04 indica CC BY-NC 3.0 España. La atribución a los autores no implica que hayan validado este modelo. El paquete no incluye el PDF completo.

Firma: **IberOS · PICOLA-3D**. Reconstrucción científica de trabajo; versión no definitiva.
