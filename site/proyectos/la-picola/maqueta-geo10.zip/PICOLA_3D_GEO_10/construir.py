"""IberOS · PICOLA-3D | GEO-10. Maqueta documental parcial, sin cotas arqueológicas.
Ejecutar desde la carpeta raíz de trabajo. Requiere numpy y matplotlib.
"""
from pathlib import Path
import json, math, shutil, zipfile
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from matplotlib.patches import Patch

ROOT=Path(__file__).resolve().parent.parent
OUT=Path(__file__).resolve().parent
reg=json.loads((ROOT/'PICOLA_3D_GEO_09/registro_encuentros.json').read_text())
cal=json.loads((ROOT/'PICOLA_3D_GEO_09/calibracion_GEO02_referencia.json').read_text())
A=np.array(reg['matrix_A']); b=np.array(reg['offset_b']); G=np.array(cal['native_xy_to_EN_matrix'])
def en(xy):
    q=np.array(xy)@A.T+b
    return np.c_[q,np.ones(len(q))]@G
origin=en([[180,404]])[0]
items=[]
def poly(id,pts,status,note):
    p=en(pts)-origin
    # A positive winding gives consistent prism face normals.
    if np.sum(p[:,0]*np.roll(p[:,1],-1)-np.roll(p[:,0],-1)*p[:,1])<0:
        p=p[::-1]
    items.append(dict(id=id,source_pdf_polygon=pts,local_EN_m=p.tolist(),
        evidence=status,note=note,height_display_m=.8 if status=='documentada_en_planta' else .12,
        ancient_height_m=None,base_elevation_m=None))
def rect(id,x,y,X,Y,status='documentada_en_planta',note='Trazo oscuro de figura 3; contorno simplificado manualmente.'):
    poly(id,[[x,y],[X,y],[X,Y],[x,Y]],status,note)
D='documentada_en_planta'; I='restituida_en_publicacion'
# Subset of identifiable dark traces, not automatic extraction of every black pixel.
poly('M_NO',[[181,400],[397,402],[397,409],[181,407]],D,'Cortina NO: huella esquemática del tramo oscuro. No se fuerza a horizontalidad ni perpendicularidad.')
poly('M_NE_sur_puerta',[[153,235],[161,234],[172,291],[164,292]],D,'Cortina NE, tramo conservado contiguo al lado superior de la puerta en la lámina.')
poly('M_NE_norte_puerta',[[168,321],[176,320],[190,400],[181,402]],D,'Cortina NE, tramo oscuro hacia torre N. Hueco de puerta abierto, sin alzado supuesto.')
poly('T_N',[[168,389],[180,387],[184,400],[181,407],[171,407]],D,'Torre N: aproximación del contorno oscuro. No asigna cota ni altura antiguas.')
rect('NE_fragmento',153,212,157,218)
rect('A_frente_01',184,374,215,377)
rect('A_frente_02',222,374,228,377)
rect('A_frente_03',233,372,242,376)
rect('A_frente_04',307,373,316,376)
rect('A_frente_05',389,373,392,376)
for id,x,y,X,Y in [
 ('A_tab_01',200,376,203,400),('A_tab_02',214,384,217,400),
 ('A_tab_03',249,394,252,400),('A_tab_04',263,380,266,400),
 ('A_tab_05',293,387,296,400),('A_tab_06',307,393,310,400),
 ('A_tab_07',307,380,310,386),('A_tab_08',322,387,325,400),
 ('A_tab_09',350,379,353,396),('A_tab_10',369,385,372,394),
 ('A_sub_01',188,390,201,392),('A_sub_02',230,388,235,391),
 ('A_sub_03',241,389,245,391),('A_sub_04',252,390,264,393),
 ('A_sub_05',294,388,304,391),('A_sub_06',314,391,323,394),
 ('A_sub_07',355,393,370,395),
 ('BC_frente_01',178,329,191,332),('BC_frente_02',189,321,203,324),
 ('BC_tab_01',199,322,202,332),('BC_tab_02',188,343,191,357),
 ('BC_sub_01',188,339,193,342),('BC_sub_02',196,339,201,342),
 ('BC_sub_03',180,355,195,358),('BC_frag_01',204,355,206,358),
 ('BC_sub_04',286,328,301,331),('BC_sub_05',295,338,300,340),
 ('BC_sub_06',289,355,302,358),('C_frente',181,302,190,305)]:rect(id,x,y,X,Y)
poly('BC_tab_03',[[292,330],[295,330],[299,356],[296,356]],D,'Tabique B8/B9 oscuro, lectura esquemática.')
poly('C_tab',[[185,305],[188,305],[190,317],[187,317]],D,'Fragmento oscuro entre C1/C2.')
# Published light reconstruction. Kept as a separate low relief, not excavated walls.
poly('R_SE',[[134,186],[397,186],[398,193],[136,193]],I,'Cortina SE clara de Moret; restitución histórica, no tramo excavado.')
poly('R_SO',[[394,190],[401,190],[415,407],[407,407]],I,'Cortina SO clara de Moret; contorno aproximado.')
poly('R_NE_superior',[[134,190],[141,190],[153,235],[146,235]],I,'Continuidad clara de cortina NE; excluye la puerta.')
poly('R_NE_inferior',[[172,291],[179,290],[184,320],[177,321]],I,'NO USAR: este polígono se elimina abajo para conservar íntegro el hueco de puerta.')
items=[x for x in items if x['id']!='R_NE_inferior']
for j,(x,y,X,Y) in enumerate([(215,374,222,377),(228,374,233,377),(242,374,307,377),(316,374,389,377),
 (214,377,217,384),(230,377,233,388),(246,377,249,394),(278,377,281,400),
 (293,377,296,387),(321,377,324,387),(335,377,338,400),(365,377,368,385),
 (201,329,286,332),(301,329,319,332),(195,355,204,358),(206,355,289,358),
 (302,355,360,358),(178,302,181,321),(190,302,264,305)]):
    rect(f'R_interior_{j+1:02}',x,y,X,Y,I,'Trazo claro restituido en figura 3, simplificado manualmente. Inventario parcial, sin completar habitaciones ausentes.')

meta={'firma':'IberOS · PICOLA-3D','version':'GEO-10','scope':'Maqueta volumétrica documental parcial de la fase ibérica',
 'source':'Moret y Badie 1998, figura 3, p. 55; huellas manuales simplificadas, no levantamiento vectorial original',
 'source_doi':'https://doi.org/10.3989/aespa.1998.v71.274',
 'orientation':reg['angles'],'registration':'GEO-09, provisional; 4 referencias gráficas y 2 comprobaciones no ciegas',
 'local_axes':'X=Este de cuadrícula; Y=Norte de cuadrícula; Z=altura de representación en metros',
 'local_origin_documentary_EPSG25830':origin.tolist(),'real_world_error_m':None,
 'height_warning':'0,80 m / 0,12 m son alturas de visualización elegidas para distinguir capas. No son alturas conservadas ni reconstruidas antiguas.',
 'elevation_warning':'Base Z=0 arbitraria, sin altitud arqueológica.',
 'omissions':['Inventario de huellas parcial: no todos los fragmentos de figura 3 están digitalizados.',
 'Sin cubiertas, almenas, segunda torre ni alzado de puerta.', 'Foso/escarpa sin geometría 3D: faltan secciones y cotas.',
 'Paleocosta y humedales pendientes de capa cronológica independiente; no se ha trazado una orilla nueva.',
 'Sin conexión geométrica a PICOLA-CAMINOS.', 'REC-63 no recuperado en esta tanda; no se atribuye este modelo a aquel archivo.'],
 'elements':items}
(OUT/'modelo_parametrico.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
features=[]
for it in items:
    p=np.array(it['local_EN_m'])+origin
    features.append({'type':'Feature','properties':{k:v for k,v in it.items() if k not in ['local_EN_m','source_pdf_polygon']},
        'geometry':{'type':'Polygon','coordinates':[[*p.tolist(),p[0].tolist()]]}})
# EPSG25830 encoded in filename/properties; this is an explicit projected GIS interchange,
# not RFC7946 longitude/latitude GeoJSON.
(OUT/'huellas_EPSG25830.geojson').write_text(json.dumps({'type':'FeatureCollection','name':'IberOS_GEO10_documental_provisional',
 'crs':{'type':'name','properties':{'name':'EPSG:25830'}},'features':features},ensure_ascii=False))

colors={D:'#366d78',I:'#cf9d4d'}
def faces(p,h):
    low=np.c_[p,np.zeros(len(p))];high=np.c_[p,np.full(len(p),h)]
    return [low[::-1],high]+[np.array([low[i],low[(i+1)%len(p)],high[(i+1)%len(p)],high[i]]) for i in range(len(p))]
mtl='newmtl documentada_en_planta\nKd 0.21 0.43 0.47\n\nnewmtl restituida_en_publicacion\nKd 0.81 0.62 0.30\n'
(OUT/'IberOS_Picola.mtl').write_text(mtl)
obj=['# IberOS · PICOLA-3D GEO-10. Z visual, sin cotas antiguas.','mtllib IberOS_Picola.mtl'];idx=1
for it in items:
    p=np.array(it['local_EN_m']);h=it['height_display_m'];n=len(p)
    obj += [f'o {it["id"]}',f'usemtl {it["evidence"]}']
    obj += [f'v {x:.6f} {y:.6f} {z:.6f}' for x,y,z in np.vstack([np.c_[p,np.zeros(n)],np.c_[p,np.full(n,h)]])]
    obj += ['f '+' '.join(str(idx+i) for i in reversed(range(n))), 'f '+' '.join(str(idx+n+i) for i in range(n))]
    obj += [f'f {idx+i} {idx+(i+1)%n} {idx+n+(i+1)%n} {idx+n+i}' for i in range(n)]
    idx+=2*n
(OUT/'IberOS_Picola.obj').write_text('\n'.join(obj)+'\n')
allp=np.concatenate([np.array(x['local_EN_m']) for x in items]);lo=allp.min(0)-3;hi=allp.max(0)+3
fig=plt.figure(figsize=(14,9),facecolor='#f6f4ef'); ax=fig.add_subplot(121,projection='3d'); ax2=fig.add_subplot(122)
for it in items:
    p=np.array(it['local_EN_m']);c=colors[it['evidence']]
    ax.add_collection3d(Poly3DCollection(faces(p,it['height_display_m']),facecolor=c,edgecolor=c,linewidth=.2))
    ax2.fill(p[:,0],p[:,1],color=c,alpha=1)
ax.set(xlim=(lo[0],hi[0]),ylim=(lo[1],hi[1]),zlim=(0,8));ax.set_box_aspect((hi[0]-lo[0],hi[1]-lo[1],8));ax.view_init(40,-60)
ax.set_xlabel('Este local (m)');ax.set_ylabel('');ax.set_zticks([0,4,8]);ax.set_zlabel('');ax.set_title('Volumen de representación\nAlzados antiguos sin determinar',pad=15)
ax2.set_aspect('equal');ax2.set_xlim(lo[0],hi[0]);ax2.set_ylim(lo[1],hi[1]);ax2.set_xlabel('Este local (m)');ax2.set_ylabel('Norte de cuadrícula (m)');ax2.grid(alpha=.15);ax2.set_title('Huellas simplificadas e inventario parcial\nOrientación heredada de GEO-09')
ax2.annotate('N cuadrícula',xy=(hi[0]-5,hi[1]-1),xytext=(hi[0]-5,hi[1]-10),arrowprops={'arrowstyle':'->'},ha='center',fontsize=8)
fig.suptitle('IberOS · PICOLA-3D | GEO-10\nMaqueta documental de trabajo · orientación provisional',fontsize=19,y=.97)
fig.legend(handles=[Patch(color=colors[D],label='Huella documentada; altura visual 0,80 m'),Patch(color=colors[I],label='Restitución publicada; relieve visual 0,12 m')],loc='lower center',bbox_to_anchor=(.5,.115),ncol=2,frameon=False)
fig.text(.06,.065,'NO ≈ 58° · NE ≈ 137° geográficos. Posición absoluta y alturas antiguas sin validar.\nSin cubiertas, paleocosta ni enlace a caminos: esas capas requieren evidencia propia.',fontsize=10)
fig.text(.06,.02,'IberOS · 22/10/2026 | Fuente: Moret y Badie (1998), fig. 3, p. 55. Derivación manual no comercial.\nLas formas se han simplificado: no usar como levantamiento de campo ni medir espesores arqueológicos desde esta maqueta.',fontsize=9)
fig.subplots_adjust(bottom=.23,top=.80,wspace=.32)
fig.savefig(OUT/'IberOS_PICOLA_GEO10_maqueta.png',dpi=160);plt.close(fig)

template=(OUT/'visor_base.html').read_text()
(OUT/'IberOS_Picola_3D.html').write_text(template.replace('__DATA__',json.dumps(meta,ensure_ascii=False)))
print(json.dumps({'elements':len(items),'documented':sum(i['evidence']==D for i in items),'published_reconstructions':sum(i['evidence']==I for i in items),'origin':origin.tolist(),'bounds_m':(hi-lo).tolist()},indent=2))
